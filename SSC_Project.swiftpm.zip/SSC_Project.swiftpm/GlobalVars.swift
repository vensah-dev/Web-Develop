//
//  GlobalVars.swift
//  SSC_Project
//
//  Created by Venkatesh Devendran on 03/02/2024.
//

import Foundation
import SwiftUI

//enum for ease of use
enum tutorialContentStyle{
    case title, header1, bodyText, code, webView
}

//tutorial struct
struct tutorialData{
    let ID = UUID()
    var content: String
    var style: tutorialContentStyle
}

//all the tutorials in order in a 2D array (maybe not the best way to do this but this was the first thing that came to my mind...)
var tutorial: [[tutorialData]] = [
    [
        tutorialData(content: "Hello, World!", style: tutorialContentStyle.title),
        
        tutorialData(content: "Have you ever written code in your life before? Have you wondered how hard it would be to make a website? I did (a few months ago) and I learnt how to develop websites using HTML and CSS. Learning these markup languages made me realise how easy and quick they are to learn. This made me think, if learning HTML and CSS would allow one to build their own website how long would it take to teach someone HTML and CSS to make their own website that can be used in real life? The answer is this App playground! In the next few minutes you will be introduced to the world of web development and also would be able to make your very own portfolio website about yourself!", style: tutorialContentStyle.bodyText),
        
        tutorialData(content: "What you would be able to build by the end", style: tutorialContentStyle.title),
        tutorialData(content: 
                     """
                     Scroll Down
                     ⌄
                     """, style: tutorialContentStyle.header1),

        tutorialData(content: """
                     <!DOCTYPE html><html><!—Header—><head><title>Sample Website</title><style> body, html{    margin: 20px;    font-family: Monospace;    color: white;    background-color: #1e1e1e;}.main-title{    font-size: 42px;}.html-about, .css-about{    color: white;    border-radius: 10px;    font-size: 15px;}.html-about{    background-color: #385d9c;    font-family: Monospace;}.css-about{    background-color: #389c56;    font-family: Helvetica;}.html-title{    font-style: italic;    font-size: 36px;}.css-title{    font-style: italic;    font-family: Helvetica;}.text{    padding: 10px;}</style></head><!—body—><body>    <h1 class="main-title">Markup Languages</h1>    <h4>A markup language is a text-encoding system which specifies the structure and formatting of a document and potentially the relationship between its parts. Markup can control the display of a document or enrich its content to facilitate automated processing. <br>  <br>  ~ Wikipedia</h4>    <div class = "html-about">        <h1 class=" html-title" style="padding: 10px 0px 0px 10px">HTML</h1>        <h4 class="text">HyperTextMarkupLanguage(HTML) is a markup language which means it is used to format your website. This website was also made using HTML combined with seom CSS. A HTML file usually has three main elements: html: the main element where the head and body live, head: can be used to link CSS and set title for website, body: where the website's content lives</4>    </div>    <div class = "css-about">        <h1 class = "css-title" style="padding: 10px 0px 0px 10px">CSS</h1>        <h4 class="text">Cascading Style Sheets(CSS) is also markup language which enables you to style your HTML content. You would be able to change things like color font size and other parameters using it. The main use of CSS si to control webpage layouts and designs. CSS allows developers to easily change parameters of HTML elements to suit your design well.</4>    </div></body></html>
                     """, style: tutorialContentStyle.webView),
        tutorialData(content: "A simple wesbite like this will be coded completely by you at the end of the next few minutes!", style: tutorialContentStyle.bodyText)

    ],
    
    [
        tutorialData(content: "How does HTML work?", style: tutorialContentStyle.title),
        tutorialData(content: "The root element or the main group would be the <HTML> this is how you start your HTML code. Cascading Style Sheets(CSS) is also markup language which enables you to style your HTML content. You would be able to change things like  color font size and other parameters using it.The <HTML> would also have too end with </HTML> like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <HTML>
                     
                     </HTML>
                     """,
                     style: tutorialContentStyle.code),
        
        tutorialData(content: "Inside of your <HTML> element the next 2 elements you would be adding in are the <head> and <body> they are also added just like the <HTML> element but inside of the <HTML> element like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <HTML>
                     
                     <head>
                     </head>
                     
                     <body>
                     </body>
                     
                     </HTML>
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "One thing to note is that its good practice to declare that the file is an HTML file at the very top with this code:", style: tutorialContentStyle.bodyText),
        tutorialData(content:"<!DOCTYPE html>", style: tutorialContentStyle.code),
        tutorialData(content: "This is the code so far:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!DOCTYPE html>
                     <HTML>
                     
                     <head>
                     </head>
                     
                     <body>
                     </body>
                     
                     </HTML>
                     """,
                     style: tutorialContentStyle.code),
        
        tutorialData(content: "This might seem messy and hard to keep track of so one thing you can do is add comments to sections of the code to explain whats going on. Comments are just lines of code that don't affect your final result and are just there for our reference. A comment can be added in HTML like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!--This is a comment-->
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "The code that we have gone through so far is just boilerplate code which is code that is needed to start all your HTML code. The whole boilerplate code would look like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!DOCTYPE html>
                     
                     <html>
                     
                     <!—Header—>
                     <head>

                     </head>
                     
                     <!—body—>
                     <body>

                     </body>
                     </html>
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "You can long press the code block to copy the code", style: tutorialContentStyle.bodyText),
        tutorialData(content: "After all that setup we are ready to start displaying stuff by literally just writing anything you want in the body element. Even though it would work without indentation it is good practice to tab once before writing your content like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     ...
                     
                     <body>
                        Hello, World!
                     </body>
                     
                     ...
                     """,
                     style: tutorialContentStyle.code),
        
    ],
    
    [
        tutorialData(content: "Header Tags <>", style: tutorialContentStyle.title),
        
        tutorialData(content: "What are tags?", style: tutorialContentStyle.header1),
        tutorialData(content: "HTML tags are basically what define how your text is shown on HTML. Think of it as a keyword or as I like to think of it: how you format your text. Almost all tags have an opening and closing tag, the opening tag looks something like <tag> and the closing tag would look like </tag>.", style: tutorialContentStyle.bodyText),

        
        tutorialData(content: "How header tags work", style: tutorialContentStyle.header1),
        tutorialData(content:
                        """
                        Header tags allow you easily format your text. There are 5 main header tags:
                        h1, h2, h3, h4, h5 and h6
                        
                        h1 is the biggest text often used for titles
                        h2 is like secondary title, which can be used for sub-headers
                        h3 is like tertiary title, which can be used for sub sections
                        h4 on the other hand can be used for body text
                        h5 is the same as h4 but smaller
                        h6 is *surprise* *surprise* just another smaller text and the least commonly used header tag

                        The tags are to be used like the following:
                        """,
                     style: tutorialContentStyle.bodyText),
        
        tutorialData(content: "<h1>The text here</h1>", style: tutorialContentStyle.code),
        
        tutorialData(content: "For the other header tags they all follow the same format except the h1 is replaced with the header number of your choice like:", style: tutorialContentStyle.bodyText),
        
        tutorialData(content:
                     """
                     <h2>The text here</h2>
                     <h3>The text here</h3>
                     ...
                     """,
                     style: tutorialContentStyle.code),
        
        tutorialData(content: "Other tags", style: tutorialContentStyle.header1),
        tutorialData(content: "You might be wondering how to display a title on the window of your website. Even if you weren't you're learning that too. Under the <head> element you can add in a <title> tag with your title and thats it. Simple right? Here is the code:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <title>My Website</title>
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "You might also be wondering how to make a new line. Yet again, even if you weren't you're learning that too. Under the <body> element you can add in a <br> tag this time it doesn’t have a closing tag its just <br> Here is an example:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <h1>Hello</h1>
                     <!--This is where the line breaks into a new line-->
                     <br>
                     <h1>World!</h1>
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "You might also be wondering how to make a paragraph. Yet again(I'm getting as tired of this as you are), even if you weren't you're learning that too. Under the <body> element you can add in a <p> tag and then you can add text of any style in there. Here is an example:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!--paragraph-->
                     <p>
                     
                     <!--the text contents-->
                     <h1>Hello</h1>
                     <br>
                     <h1>World!</h1>
                     
                     </p>
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "You can also use tags to group a bunch of elements like other tags and text together. This will be more useful when you learn CSS to style these groups. These groups can be made using the <div> tag like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!--div-->
                     <div>
                     
                     <!--the contents-->
                     <h1>Hello</h1>
                     <br>
                     <h1>World!</h1>
                     
                     </div>
                     """,
                     style: tutorialContentStyle.code),

        tutorialData(content: "Now it's your turn", style: tutorialContentStyle.header1),
        tutorialData(content: "You can now add title to your website and headers, sub-headers and body texts! Play around with it and write a section about you, section about your skills and a section about your projects. Be creative and customise your website to your liking!", style: tutorialContentStyle.bodyText),
        
    ],
    
    [
        tutorialData(content: "What is CSS?", style: tutorialContentStyle.title),
        tutorialData(content: "", style: tutorialContentStyle.bodyText),
        
        tutorialData(content: "How does CSS work?", style: tutorialContentStyle.title),
        tutorialData(content: "To use CSS with your HTML content you first have to link the CSS file in your HTML code this can be done with the following code that needs to be placed under the <head> element:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <link rel="stylesheet" href="stylesheet.css">
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "The code has 2 main parts the rel= which is to tell HTML that we are linking to a stylesheet which is basically a CSS file. the href= is the URL to your CSS file in our case it would be stylesheet.css", style: tutorialContentStyle.bodyText),
        
        tutorialData(content: "The final thing to learn before CSS is class in HTML, this is just an identifier that can be put inside of the opening tag like this for example:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <h1 class = "hello-world">Hello, World!</h1>
                     """,
                     style: tutorialContentStyle.code),
        
    ],
    
    [
        tutorialData(content: "Styling with CSS", style: tutorialContentStyle.title),
        tutorialData(content: "Using tags", style: tutorialContentStyle.header1),
        tutorialData(content: "To style with CSS you can refer to a specific tag to change its parameters. For example lets say we have a <h1> and we want to change the color of it we can use the change the color property from within the CSS file like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     h1{
                        color: red;
                     }
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "You can also use a hex color code like #4287f5 instead of red for custom colors", style: tutorialContentStyle.bodyText),
        tutorialData(content: "The result should look like this", style: tutorialContentStyle.bodyText),
        tutorialData(content: "<!DOCTYPE html><html><!—Header—><head> <style> h1{    color: red;}</style></head>   <!—body—><body>    <h1>Hello, World!</h1>   </body></html>", style: tutorialContentStyle.webView),
        
        
        tutorialData(content: "Changing things in an element can be done in a similar way. For example if you want to change the background color you can use the background-color property on the body like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     body{
                        background-color: red;
                     }
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "The result should look like this", style: tutorialContentStyle.bodyText),
        tutorialData(content: "<!DOCTYPE html><html><!—Header—><head> <style> h1{    color: red;}</style></head>   <!—body—><body>    <h1>Hello, World!</h1>   </body></html>", style: tutorialContentStyle.webView),
        tutorialData(content: "As you can see in CSS you would have to use squiggly brackets and put your properties inside of it and end every line that is changing or assigning a property with a semicolon.", style: tutorialContentStyle.bodyText),


        tutorialData(content: "Using classes", style: tutorialContentStyle.header1),
        tutorialData(content: ".class can also be used in replacement of the tags, changing the previous example a bit to the following will also give the same results:", style: tutorialContentStyle.bodyText),
        tutorialData(content: "CSS", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     .hello-world{
                        color: red;
                     }
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content:
                     """
                     <h1 class = "hello-world">Hello, World!</h1>
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "The result should look like this", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!DOCTYPE html><html><!—Header—><head> <style> .hello-world{    color: red;}</style></head>   <!—body—><body>    <h1 class = "hello-world">Hello, World!</h1>   </body></html>
                     """,
                     style: tutorialContentStyle.webView),
        
    ],
    
    [
        tutorialData(content: "CSS properties", style: tutorialContentStyle.title),

        tutorialData(content: "There are also other different properties that are all used in similar ways just with their different names like font properties the usage for all of them is as follows:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     /*This is how you make a comment in CSS by the way*/
                     .hello-world{
                        background-color: blue;
                     
                        /*fonts*/
                        font-family: Helvetica;
                        font-size: 18px;
                        font-style: italic;
                        font-weight: bold;
                     
                        /*border*/
                        border-radius: 10px;
                        margin: 0px;
                     
                        /*size*/
                        width: 500px;
                        height: 350px;
                     }
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "properties like border-radius and margin and font-size require you to add 'px' after a number. px stands for pixels which basically tells CSS how many pixels the margin or font is supposed to be or how many pixels the border has to be rounded. As of now you should not find a use for margin and border-radius they will be covered in the next page.", style: tutorialContentStyle.bodyText),
        tutorialData(content: "font-family", style: tutorialContentStyle.header1),

        tutorialData(content: "One property that needs its own short paragraph is the font-family paragraph. Unlike otehr properties it haa specific fonts that you can use. Since we are on iOS we have Helvetica as one of those default fonts. Not only that but there is also Monospace ", style: tutorialContentStyle.bodyText),


        tutorialData(content: "Now it's your turn", style: tutorialContentStyle.header1),
        tutorialData(content: "Now that you know CSS you can now edit your website to have your favourite colors, different font sizes and shapes!", style: tutorialContentStyle.bodyText),
        
    ],
    
    [
        tutorialData(content: "styling <div>", style: tutorialContentStyle.title),
        
        tutorialData(content: "As mentioned before(way before), you can use divs to style the contents. A div can be visualised as a group of elements which means when you apply style properties like border-radius they would affect the shape of it. Thus, you would be able to make results like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!DOCTYPE html><html><!—Header—><head> <style> .hello-world{    color: darkred; background-color: lightblue; border-radius: 5px;}</style></head>   <!—body—><body>    <h1 class = "hello-world">Hello, World!</h1>   </body></html>
                     """,
                     style: tutorialContentStyle.webView),
        
        tutorialData(content: "This was the code used to achieve the result above:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     .hello-world{
                        color: darkred;
                        background-color: lightblue;
                        border-radius: 10px;
                     }
                     """,
                     style: tutorialContentStyle.code),
        
        tutorialData(content:
                     """
                     ...
                     
                     <body>
                        <div class = "hello-world">
                            <h1>Hello, World!</h1>
                        </div>
                     </body>
                     
                     ...
                     """,
                     style: tutorialContentStyle.code),
        tutorialData(content: "What is that? You want to make the <div> span across the entire width of the screen with no border radius? No problem! You need to set the margin of the website to 0px to ensure that the website has no spacing near the edges. This needs to be done to the body and html elements like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     body, html{
                        margin: 0px;
                     }
                     """,
                     style: tutorialContentStyle.code),
        
        tutorialData(content:
                     """
                     <!DOCTYPE html><html><!—Header—><head> <style> body,html{margin: 0px;} .hello-world{color: darkred; background-color: lightblue;}</style></head>   <!—body—><body>    <h1 class = "hello-world">Hello, World!</h1>   </body></html>
                     """,
                     style: tutorialContentStyle.webView),
        
        tutorialData(content: "Now you might notice that the text 'Hello, World!' is very close to the left edge and looks kind of ugly. To change this you can add padding. For those who have worked with UI before you should be instantly familiar with this term, but if you haven’t it’s basically adding spacing around an element. It can be done in CSS like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     .hello-world{
                        color: darkred;
                        background-color: lightblue;
                        border-radius: 10px;
                        padding: 10px;
                     }
                     """,
                     style: tutorialContentStyle.code),
        
        tutorialData(content: "Now the result should look like this:", style: tutorialContentStyle.bodyText),
        tutorialData(content:
                     """
                     <!DOCTYPE html><html><!—Header—><head> <style> body,html{margin: 0px;} .hello-world{color: darkred; background-color: lightblue; padding: 10px;}</style></head>   <!—body—><body>    <h1 class = "hello-world">Hello, World!</h1>   </body></html>
                     """,
                     style: tutorialContentStyle.webView),
        
        tutorialData(content: "Now you are equipped with the knowledge of basic styling for <div>!", style: tutorialContentStyle.header1),

    ],
    
    [
        tutorialData(content: "Experiment", style: tutorialContentStyle.title),
        
        tutorialData(content: "Now that you have learnt a bit of CSS and HTML I hope this has sparked your interest for web development and hopefully would do more web development and enjoy it like me! From here it’s up to you to choose what you’re going to do to continue with the development of your website. I would highly recommend tinkering around with your website to find out what can work and what doesn't and maybe if your 'lucky' enough you would get to spend 2 hours debugging to realise that you used single quotations instead of double quotations when giving a tag a class 😆", style: tutorialContentStyle.bodyText),
    ],
]

//extra newlines here just to make thsi file exactly 400 lines 😜
