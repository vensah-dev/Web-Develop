//
//  DataManager.swift
//  SSC_Project
//
//  Created by Venkatesh Devendran on 04/02/2024.
//

import Foundation
import SwiftUI

class DataManager: ObservableObject {
    //an array of the HTML and CSS files with placeholders in each
    @Published var codeFiles: [String] = [
        """
        """,
        """
        /*This is a CSS comment*/
        """,
    ]
    {
        //save the code so that its saved when the user leaves and comes back to the app
        didSet {
            save()
        }
    }
    
    //load the code saved last time
    init() {
        load()
    }
    
    //generate the File path to store the code data
    func getArchiveURL() -> URL {
        let plistName = "codeFiles.plist"
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!

        return documentsDirectory.appendingPathComponent(plistName)
    }
    
    //store the code at the file path generated
    func save() {
        let archiveURL = getArchiveURL()
        let propertyListEncoder = PropertyListEncoder()
        let encodedStrings = try? propertyListEncoder.encode(codeFiles)
        try? encodedStrings?.write(to: archiveURL, options: .noFileProtection)
    }
    
    //load the stored code from the save file path
    func load() {
        let archiveURL = getArchiveURL()
        let propertyListDecoder = PropertyListDecoder()
                
        if let retrievedStringData = try? Data(contentsOf: archiveURL),
            let codeFilesDecoded = try? propertyListDecoder.decode([String].self, from: retrievedStringData) {
            codeFiles = codeFilesDecoded
        }
    }
}
