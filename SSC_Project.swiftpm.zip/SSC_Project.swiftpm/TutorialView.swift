//
//  TutorialView.swift
//  SSC_Project
//
//  Created by Venkatesh Devendran on 04/02/2024.
//

import SwiftUI

struct TutorialView: View {
    @Binding var tutorialNo: Int
    @State var fullscreen: Bool = false
    @Binding var state: Int
    
    //thsi is here to provide the scroll view to have a id and when i change it the scroll view rebuilds itself and it scrolls to the top when swicthing between tutorials
    @State private var scrollViewID = UUID()



    var body: some View {
        ZStack{
            if !fullscreen{
                Color("BackgroundSecondary")
            }
            
            VStack{
                ScrollView{
                    VStack{
                        ForEach(tutorial[tutorialNo].indices, id: \.self){ i in
                            //get the current tutorial and loop through all of its contents and styel appropriately
                            let item = tutorial[tutorialNo][i]
                            
                            if(item.style == tutorialContentStyle.title){
                                Text(item.content)
                                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                                    .foregroundColor(Color.accentColor)
                                    .padding()
                            }
                            else if (item.style == tutorialContentStyle.header1){
                                Text(item.content)
                                    .font(.system(size: 24, weight: .bold, design: .rounded))
                                    .multilineTextAlignment(.center)
                            }
                            else if (item.style == tutorialContentStyle.bodyText){
                                Text(item.content)
                                    .font(.system(size: 17, weight: .none, design: .rounded))
                                    .multilineTextAlignment(.center)
                                    .padding()
                            }
                            else if (item.style == tutorialContentStyle.code){
                                ZStack(alignment: .leading){
                                    
                                    Color("BackgroundSecondary")
                                    
                                    Text(item.content)
                                        .font(.system(size: 14, weight: .light, design: .monospaced))
                                        .foregroundColor(.secondary)
                                        .padding(10)
                                    
                                }
                                .textSelection(.enabled)
                                .cornerRadius(8)
                                .padding(.horizontal)


                            }
                            else if (item.style == tutorialContentStyle.webView){
                                if fullscreen{
                                    WebsitePreview(fullScreen: $fullscreen, disableFullScreen: true, htmlString: item.content)
                                        .frame(minHeight: 500)
                                        .padding(.horizontal)
                                }
                                else{
                                    WebsitePreview(fullScreen: $fullscreen, disableFullScreen: true, htmlString: item.content)
                                        .frame(minHeight: 250)
                                        .padding(.horizontal)
                                }
                            }
                        }
                        
                        //button here if tutorial is not fullscreen
                        if !fullscreen{
                            tutorialButtonsView(tutorialNo: $tutorialNo, state: $state, fullscreen: fullscreen)
                                .padding(.vertical)

                        }
                    }
                    .padding()

                }                
                .background(Color("BackgroundTertiary"))
                .id(scrollViewID)
                .onChange(of: tutorialNo) { _ in
                    //this seems to be the most effecient way to reload this scrollView to make it scroll to the top
                    scrollViewID = UUID()
                }
                
                //button displayed at the bottom if fullscreen tutorial
                if fullscreen{
                    tutorialButtonsView(tutorialNo: $tutorialNo, state: $state, fullscreen: fullscreen)
                        .padding(.vertical, 25)

                }
                
            }
            .background(Color("BackgroundTertiary"))
            .cornerRadius(8)
            //no padding if sull screen tutorial so that it looks nice
            .padding(fullscreen ? 0:8)
        }
    }
}

struct tutorialButtonsView: View {
    @Binding var tutorialNo: Int
    @Binding var state: Int
    @State var fullscreen: Bool

    
    var body: some View {
        HStack(spacing: 10){
            //back button
            if tutorialNo > 0{
                Button{
                    tutorialNo -= 1
                    
                    if(tutorialNo == 2){
                        state = 0
                    }
                    
                }label:{
                    Text("Back")
                        .padding(10)
                        .padding(.horizontal, 5)
                        .foregroundColor(.white)
                        .background(Color.accentColor)
                        .font(.system(size: 17, weight: .none, design: .rounded))
                        .cornerRadius(25)
                }
            }
            
            //next button
            if tutorialNo < tutorial.count-1{
                Button{
                    if tutorialNo < tutorial.count{
                        tutorialNo += 1
                    }
                    
                    if(tutorialNo == 1){
                        state = 0
                    }
                    
                    print(tutorial.count)
                    
                }label:{
                    
                    //set custom next button text if applicable
                    Text(tutorialNo == 0 ? "Get Started!":"Next")
                        .padding(10)
                        .padding(.horizontal, 5)
                        .foregroundColor(.white)
                        .background(Color.accentColor)
                        .font(.system(size: 17, weight: .none, design: .rounded))
                        .cornerRadius(25)
                }
            }
        }
    }
}
