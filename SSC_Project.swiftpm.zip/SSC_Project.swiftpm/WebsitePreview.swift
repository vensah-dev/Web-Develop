//
//  WebsitePreview.swift
//  SSC_Project
//
//  Created by Venkatesh Devendran on 03/02/2024.
//

import SwiftUI
import WebKit

struct WebsitePreview: View {
    @State private var error: Error? = nil
    @State private var title: String = " "
    @Binding var fullScreen: Bool
    @State var disableFullScreen: Bool = false

    let htmlString: String?
    
    var body: some View {
        NavigationStack{
            ZStack {

                if let error = error {
                    //I know I probabaly wont need this for a HTML string but I programmed the error handling and THEN realised that so its staying here in recognition of my effort of decalring ONE variable
                    Text(error.localizedDescription)
                        .foregroundColor(.pink)
                    
                } else if let htmlString = htmlString {
                    //website preview
                    ZStack{
                        Color("BackgroundSecondary")
                        
                        VStack(alignment: .leading){
                            //window tab header
                            HStack{
                                //maximise/minimise button
                                if !disableFullScreen{
                                    Button{
                                        print("maximals maximise")
                                        withAnimation {
                                            fullScreen.toggle()
                                        }
                                    }label:{
                                        Image(fullScreen ? "MinimiseButton" : "MaximiseButton")
                                            .resizable()
                                            .frame(width: 17, height: 17)
                                    }
                                }
                                
                                //website title
                                Text(title)
                                    .font(.system(size: 14, weight: .none, design: .rounded))
                                    .padding(.leading, 10)
                            }
                            .frame(alignment: .leading)
                            
                            //actual website view
                            HTMLView(htmlString: htmlString, websiteTitle: $title)
                                .cornerRadius(8)
                        }
                        .padding(8)
                    }
                }
            }

        }
        .cornerRadius(!fullScreen || disableFullScreen ? 10 : 0)
    }
}

struct HTMLView: UIViewRepresentable {
    var htmlString: String
    @Binding var websiteTitle: String

    //intilaise everything to create a new WKWebView
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.navigationDelegate = context.coordinator
        return webView
    }
    
    //quite obviously to ensure the view updates
    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.loadHTMLString(htmlString, baseURL: nil)
    }
    
    //declare a coordinator function
    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }
    
    //declare a coordinator
    class Coordinator: NSObject, WKNavigationDelegate {
        var parent: HTMLView
        init(parent: HTMLView) {
            self.parent = parent
        }

        //get the title of the website from the HTML code given after loading the website
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.evaluateJavaScript("document.title") { (result, error) in
                if let title = result as? String {
                    if title.isEmpty{
                        //really there to ensure the padding deosnt look weird
                        self.parent.websiteTitle = " "
                    }
                    else{
                        self.parent.websiteTitle = title
                    }
                }
            }
        }
    }
}
