import SwiftUI

struct ContentView: View {
    @StateObject var dataManager = DataManager()
    
    @State var tutorialNo = 0
    @State var state = 1
    @State var showCSS = false
    @State var showImageButton = false
    @State var pickImage = false



    var body: some View {
        ZStack{
            
            if state == 0{
                CodeView(dataManager: dataManager, tutorialNo: $tutorialNo, state: $state)

            }
            else if state == 1{
                TutorialView(tutorialNo: $tutorialNo, fullscreen: true, state: $state)

            }
        }
        .ignoresSafeArea()
        .onAppear{
            print(tutorialNo)
        }
        .onDisappear{
            print(tutorialNo)
        }

    }
    
}

struct CodeView: View {
    @ObservedObject var dataManager: DataManager
        
    @Binding var tutorialNo: Int
    @Binding var state: Int
    
    @AppStorage("username") var code: String = ""
    @State var selectedFile: Int = 0
    
    @State var fullScreen: Bool = false
    
    @State private var text: String = ""
    
    var body: some View {
        ZStack{
            HStack(){
                //Code editor
                if(!fullScreen){
                    ZStack{
                        Color("BackgroundSecondary")
                        VStack(alignment: .leading){
                            //switch between CSS and HTML
                            TabBar(SelectedFile: $selectedFile)
                            
                            ZStack{
                                //a text editor for obvious reasons (for the user to write teh CSS and HTML code)
                                TextEditor(text: $dataManager.codeFiles[selectedFile])
                                //to disable smart quotes cause HTML only supports straight double quotes for parameters liek class=""
                                    .keyboardType(.asciiCapable)
                                    .disableAutocorrection(true)
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .disableAutocorrection(true)
                                    .scrollContentBackground(.hidden)
                                    .background(Color("BackgroundTertiary"))
                                    .cornerRadius(8)
                                
                            }
                            .frame(maxHeight: .infinity/2, alignment: .trailing)
                            .cornerRadius(8)
                            
                        }
                        .padding(8)
                    }
                    .cornerRadius(10)
                    //really cool slide transition
                    .transition(.move(edge: .leading))
                }
                
                VStack{
                    //website preview
                    WebsitePreview(fullScreen: $fullScreen, htmlString: code)
                        .frame(alignment: .bottom)
                        .transition(.scale)

                    //tutorial
                    if(!fullScreen){
                        TutorialView(tutorialNo: $tutorialNo, state: $state)
                            .frame(alignment: .bottom)
                            .cornerRadius(10)
                        //not so really cool slide transition
                            .transition(.move(edge: .bottom))
                        
                    }
                }
                
            }
            .padding(fullScreen ? 0 : 20)
            
            
        }
        //update when the HTML changes
        .onChange(of: self.dataManager.codeFiles[0]){ _ in
            code = makeCode(HTML: self.dataManager.codeFiles[0], CSS: self.dataManager.codeFiles[1])
        }
        //update when the CSS changes
        .onChange(of: self.dataManager.codeFiles[1]){ _ in
            code = makeCode(HTML: self.dataManager.codeFiles[0], CSS: self.dataManager.codeFiles[1])
        }
        //update when the view loads for the first time
        .onAppear{
            code = makeCode(HTML: self.dataManager.codeFiles[0], CSS: self.dataManager.codeFiles[1])
        }
    }
    
    func makeCode(HTML: String, CSS: String) -> String{
        var htmlArray = HTML.components(separatedBy: "\n")
        
         
        var i = 0
        
        
        for x in htmlArray{
            // loop through the entire HTML string find the spot to put the HTML code to link to the CSS file and replace that part with actuall CSS code  before letting the webView read the HTML String
            if x.lowercased().contains("<link") && x.lowercased().contains("rel=\"stylesheet\""){
                
                htmlArray[i] = ""
                
                var CSSArray = CSS.components(separatedBy: "\n")
                
                CSSArray.append("</style>")
                CSSArray.insert("<style> ", at: 0)
                                
                htmlArray.insert(contentsOf: CSSArray, at:i)
            }

            
            i += 1
        }
        
        print(htmlArray)
        print(htmlArray.joined())
        
        return htmlArray.joined()
        
        
    }
}

struct TabBar: View {
    @Binding var SelectedFile: Int

    var body: some View {
        ZStack(alignment: .leading){
            HStack{
                //button to chose HTML
                Button{
                    //selected file is used as the index to get the right code form the code array to be concatenated into one single HTML String for the webView
                    SelectedFile = 0
                }label:{
                    if SelectedFile == 0{
                        Text("HTML")
                            .padding(5)
                            .padding(.horizontal, 5)
                            .foregroundColor(Color(UIColor.label))
                            .background(Color.accentColor)
                            .font(.system(size: 15, weight: .none, design: .rounded))
                            .cornerRadius(25)
                        
                    }
                    else{
                        Text("HTML")
                            .padding(5)
                            .padding(.horizontal, 5)
                            .font(.system(size: 15, weight: .none, design: .rounded))
                            .foregroundColor(Color(UIColor.label))
                        
                    }
                    
                }
                
                //button to chose CSS
                Button{
                    //selected file is used as the index to get the right code form the code array to be concatenated into one single HTML String for the webView
                    SelectedFile = 1
                }label:{
                    if SelectedFile == 1{
                        Text("CSS")
                            .padding(5)
                            .padding(.horizontal, 5)
                            .foregroundColor(Color(UIColor.label))
                            .background(Color.accentColor)
                            .font(.system(size: 15, weight: .none, design: .rounded))
                            .cornerRadius(25)
                        
                    }
                    else{
                        Text("CSS")
                            .padding(5)
                            .padding(.horizontal, 5)
                            .font(.system(size: 15, weight: .none, design: .rounded))
                            .foregroundColor(Color(UIColor.label))
                        
                    }
                }
                
                Spacer()
                
            }
            .frame(height: 30, alignment: .leading)
            .cornerRadius(25)
        }
        .frame(height: 30, alignment: .leading)
    }
}
